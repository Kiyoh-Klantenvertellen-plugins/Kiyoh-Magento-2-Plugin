<?php

namespace Kiyoh\Reviews\Service;

use Kiyoh\Reviews\Api\ApiServiceInterface;
use Kiyoh\Reviews\Helper\ProductCode;
use Kiyoh\Reviews\Model\Health\HealthReporter;
use Kiyoh\Reviews\Model\Publication\PublicationServerHost;
use Kiyoh\Reviews\Model\Publication\PublicationStatisticsValidator;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Locale\Resolver as LocaleResolver;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;

class ApiService implements ApiServiceInterface
{
    private const CONFIG_PATH_ENABLED = 'kiyoh_reviews/api_settings/enabled';
    private const CONFIG_PATH_SERVER = 'kiyoh_reviews/api_settings/server';
    private const CONFIG_PATH_LOCATION_ID = 'kiyoh_reviews/api_settings/location_id';
    private const CONFIG_PATH_API_TOKEN = 'kiyoh_reviews/api_settings/api_token'; // preflight: ignore — Magento config path, not a secret
    private const CONFIG_PATH_INVITATIONS_ENABLED = 'kiyoh_reviews/review_invitations/enabled';
    private const CONFIG_PATH_INVITATION_TYPE = 'kiyoh_reviews/review_invitations/invitation_type';
    private const CONFIG_PATH_FALLBACK_LANGUAGE = 'kiyoh_reviews/review_invitations/fallback_language';
    private const CONFIG_PATH_DELAY_DAYS = 'kiyoh_reviews/review_invitations/delay_days';
    private const CONFIG_PATH_MAX_PRODUCTS = 'kiyoh_reviews/review_invitations/max_products_per_invite';
    private const CONFIG_PATH_PRODUCT_SORT_ORDER = 'kiyoh_reviews/review_invitations/product_sort_order';

    private const TIMEOUT_INVITATION = 4;
    private const TIMEOUT_REVIEWS = 2;
    private const BULK_SYNC_MAX = 200;

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;
    
    /**
     * @var EncryptorInterface
     */
    private $encryptor;
    
    /**
     * @var LoggerInterface
     */
    private $logger;
    
    /**
     * @var LocaleResolver
     */
    private $localeResolver;

    /**
     * @var ProductCode
     */
    private $productCodeHelper;

    /**
     * @var HealthReporter
     */
    private $healthReporter;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        EncryptorInterface $encryptor,
        LoggerInterface $logger,
        LocaleResolver $localeResolver,
        ProductCode $productCodeHelper,
        HealthReporter $healthReporter
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->encryptor = $encryptor;
        $this->logger = $logger;
        $this->localeResolver = $localeResolver;
        $this->productCodeHelper = $productCodeHelper;
        $this->healthReporter = $healthReporter;
    }

    public function sendShopInvitation(OrderInterface $order): bool
    {
        $result = $this->sendShopInvitationWithDetails($order);
        return $result['success'];
    }

    public function sendProductInvitation(OrderInterface $order, array $productCodes): bool
    {
        $result = $this->sendProductInvitationWithDetails($order, $productCodes);
        return $result['success'];
    }

    public function sendShopInvitationWithDetails(OrderInterface $order): array
    {
        $storeId = $order->getStoreId();

        if (!$this->isEnabled($storeId) || !$this->isInvitationsEnabled($storeId)) {
            return ['success' => false, 'error_code' => 'DISABLED', 'message' => 'Review invitations disabled'];
        }

        $invitationData = $this->buildInvitationData($order, []);
        return $this->sendInvitationRequestWithDetails($invitationData, $storeId, false);
    }

    public function sendProductInvitationWithDetails(OrderInterface $order, array $productCodes): array
    {
        $storeId = $order->getStoreId();

        if (!$this->isEnabled($storeId) || !$this->isInvitationsEnabled($storeId)) {
            return ['success' => false, 'error_code' => 'DISABLED', 'message' => 'Review invitations disabled'];
        }

        $invitationType = $this->getConfig(self::CONFIG_PATH_INVITATION_TYPE, $storeId);
        
        // Handle shop_only invitations - don't include product codes
        if ($invitationType === 'shop_only') {
            $invitationData = $this->buildInvitationData($order, []);
            return $this->sendInvitationRequestWithDetails($invitationData, $storeId, false);
        }

        $maxProducts = (int) $this->getConfig(self::CONFIG_PATH_MAX_PRODUCTS, $storeId) ?: 10;
        $limitedProductCodes = array_slice($productCodes, 0, $maxProducts);

        $productInviteFlag = ($invitationType === 'product_only'); // true = product only, false = shop + product

        $invitationData = $this->buildInvitationData($order, $limitedProductCodes);
        return $this->sendInvitationRequestWithDetails($invitationData, $storeId, $productInviteFlag);
    }

    public function sendShopAndProductInvitation(OrderInterface $order, array $productCodes): bool
    {
        $storeId = $order->getStoreId();

        if (!$this->isEnabled($storeId) || !$this->isInvitationsEnabled($storeId)) {
            return false;
        }

        $maxProducts = (int) $this->getConfig(self::CONFIG_PATH_MAX_PRODUCTS, $storeId) ?: 10;
        $limitedProductCodes = array_slice($productCodes, 0, $maxProducts);

        // For shop + product: product_invite = false, include product codes
        $invitationData = $this->buildInvitationData($order, $limitedProductCodes);
        return $this->sendInvitationRequest($invitationData, $storeId, false);
    }

    public function syncProduct(ProductInterface $product): bool
    {
        $storeId = (int) ($product->getStoreId() ?: 0);

        try {
            if (!$this->isEnabled($storeId)) {
                $this->logger->debug('Kiyoh API: Product sync skipped - API disabled', [
                    'product_sku' => $product->getSku()
                ]);
                return false;
            }

            $productData = $this->buildProductData($product);
            return $this->sendProductSyncRequest($productData, $storeId);
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Product sync exception', [
                'product_sku' => $product->getSku() ?? 'unknown',
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            $this->reportProductSync($storeId, false, null, $e->getMessage(), []);
            return false;
        }
    }

    public function syncProductsBulk(array $products): array
    {
        if (empty($products)) {
            return ['success' => 0, 'failed' => 0, 'errors' => []];
        }

        $storeId = 0;

        try {
            $storeId = (int) ($products[0]->getStoreId() ?: 0);

            if (!$this->isEnabled($storeId)) {
                $this->logger->debug('Kiyoh API: Bulk product sync skipped - API disabled');
                return ['success' => 0, 'failed' => count($products), 'errors' => ['API disabled']];
            }

            $results = ['success' => 0, 'failed' => 0, 'errors' => []];
            $batches = array_chunk($products, self::BULK_SYNC_MAX);

            foreach ($batches as $batchIndex => $batch) {
                try {
                    // Add rate limiting: wait 3 seconds between batches (except for the first batch)
                    if ($batchIndex > 0) {
                        $this->logger->info('Kiyoh API: Rate limiting - waiting 3 seconds before next batch', [
                            'batch_index' => $batchIndex,
                            'total_batches' => count($batches)
                        ]);
                        sleep(3);
                    }

                    $batchData = [];
                    foreach ($batch as $product) {
                        try {
                            $batchData[] = $this->buildProductData($product);
                        } catch (\Exception $e) {
                            $this->logger->warning('Kiyoh API: Failed to build product data in batch', [
                                'product_sku' => $product->getSku() ?? 'unknown',
                                'batch_index' => $batchIndex,
                                'exception' => $e->getMessage()
                            ]);
                            $results['failed']++;
                            $results['errors'][] = 'Failed to build data for ' . ($product->getSku() ?? 'unknown');
                        }
                    }

                    if (!empty($batchData)) {
                        $batchResult = $this->sendBulkProductSyncRequest($batchData, $storeId);
                        $results['success'] += $batchResult['success'];
                        $results['failed'] += $batchResult['failed'];
                        $results['errors'] = array_merge($results['errors'], $batchResult['errors']);
                    }
                } catch (\Exception $e) {
                    $this->logger->error('Kiyoh API: Batch processing exception', [
                        'batch_index' => $batchIndex,
                        'batch_size' => count($batch),
                        'exception' => $e->getMessage()
                    ]);
                    $results['failed'] += count($batch);
                    $results['errors'][] = 'Batch ' . $batchIndex . ' failed: ' . $e->getMessage();
                }
            }

            return $results;
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Bulk sync critical exception', [
                'total_products' => count($products),
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            $this->reportProductSync($storeId, false, null, $e->getMessage(), []);
            return ['success' => 0, 'failed' => count($products), 'errors' => ['Critical error: ' . $e->getMessage()]];
        }
    }

    public function getShopReviews(int $storeId): ?array
    {
        if (!$this->isEnabled($storeId)) {
            return null;
        }

        $server = $this->getServerUrl($storeId);
        $locationId = $this->getConfig(self::CONFIG_PATH_LOCATION_ID, $storeId);
        $apiToken = $this->getConfig(self::CONFIG_PATH_API_TOKEN, $storeId);

        if (!$locationId || !$apiToken) {
            $this->logger->error('Kiyoh API: Missing location ID or API token for shop reviews');
            return null;
        }

        $url = sprintf('%s/v1/publication/review/external/location/statistics?locationId=%s', $server, $locationId);

        try {
            $ch = curl_init($url);
            $this->applyTlsVerification($ch);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_REVIEWS);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'X-Publication-Api-Token: ' . $apiToken
            ]);

            $response = curl_exec($ch);
            curl_close($ch);

            if ($response === false) {
                $this->logger->error('Kiyoh API: Shop reviews request failed');
                return null;
            }

            $data = json_decode($response, true);

            if (isset($data['errorCode'])) {
                $this->logger->error('Kiyoh API: Shop reviews error', ['error' => $data]);
                return null;
            }

            return $data;
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Shop reviews exception', ['exception' => $e->getMessage()]);
            return null;
        }
    }

    public function getProductReviews(string $productCode, int $storeId): ?array
    {
        if (!$this->isEnabled($storeId)) {
            return null;
        }

        $server = $this->getServerUrl($storeId);
        $locationId = $this->getConfig(self::CONFIG_PATH_LOCATION_ID, $storeId);
        $apiToken = $this->getConfig(self::CONFIG_PATH_API_TOKEN, $storeId);

        if (!$locationId || !$apiToken || !$productCode) {
            $this->logger->error('Kiyoh API: Missing required data for product reviews');
            return null;
        }

        $url = sprintf(
            '%s/v1/publication/product/review/external?locationId=%s&productCode=%s',
            $server,
            $locationId,
            urlencode($productCode)
        );

        try {
            $ch = curl_init($url);
            $this->applyTlsVerification($ch);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_REVIEWS);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'X-Publication-Api-Token: ' . $apiToken
            ]);

            $response = curl_exec($ch);
            curl_close($ch);

            if ($response === false) {
                $this->logger->error('Kiyoh API: Product reviews request failed', ['productCode' => $productCode]);
                return null;
            }

            $data = json_decode($response, true);

            if (isset($data['errorCode'])) {
                $this->logger->error('Kiyoh API: Product reviews error', ['error' => $data, 'productCode' => $productCode]);
                return null;
            }

            return $data;
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Product reviews exception', ['exception' => $e->getMessage()]);
            return null;
        }
    }

    private function buildInvitationData(OrderInterface $order, array $productCodes): array
    {
        $storeId = $order->getStoreId();
        $locationId = $this->getConfig(self::CONFIG_PATH_LOCATION_ID, $storeId);
        $delayDays = $this->getConfig(self::CONFIG_PATH_DELAY_DAYS, $storeId);
        if ($delayDays === null || $delayDays === '') {
            $delayDays = 7; // Default fallback only if not configured
        } else {
            $delayDays = (int) $delayDays; // Convert to int, preserving 0
        }

        $language = $this->detectLanguageFromOrder($order, $storeId);

        $firstName = $order->getCustomerFirstname();
        $lastName = $order->getCustomerLastname();

        if (!$firstName && $order->getShippingAddress()) {
            $firstName = $order->getShippingAddress()->getFirstname();
        }
        if (!$lastName && $order->getShippingAddress()) {
            $lastName = $order->getShippingAddress()->getLastname();
        }

        $data = [
            'location_id' => $locationId,
            'invite_email' => $order->getCustomerEmail(),
            'delay' => $delayDays,
            'language' => $language,
            'first_name' => $firstName,
            'last_name' => $lastName,
            'reference_code' => $order->getIncrementId() ?? 'test-order'
        ];

        if (!empty($productCodes)) {
            $data['product_code'] = $productCodes;
        }

        return $data;
    }

    private function buildProductData(ProductInterface $product): array
    {
        try {
            $storeId = $product->getStoreId() ?: 0;
            $locationId = $this->getConfig(self::CONFIG_PATH_LOCATION_ID, $storeId);

            $rawSku = $product->getSku();
            $productCode = $this->productCodeHelper->sanitize($rawSku !== null ? (string) $rawSku : '');
            $productName = $product->getName();
            
            if (!$productCode || !$productName) {
                throw new \InvalidArgumentException('Product must have SKU and name');
            }
            
            // Ensure we have a valid product URL
            $productUrl = '';
            try {
                $productUrl = $product->getProductUrl();
            } catch (\Exception $e) {
                $this->logger->debug('Kiyoh API: Could not get product URL', [
                    'product_sku' => $productCode,
                    'exception' => $e->getMessage()
                ]);
            }
            
            if (!$productUrl || !filter_var($productUrl, FILTER_VALIDATE_URL)) {
                $productUrl = 'https://example.com/product/' . urlencode(strtolower($productCode));
            }

            // Ensure we have a valid image URL
            $imageUrl = '';
            if ($product->getImage() && $product->getImage() !== 'no_selection') {
                try {
                    $imageUrl = $product->getMediaConfig()->getMediaUrl($product->getImage());
                } catch (\Exception $e) {
                    $this->logger->debug('Kiyoh API: Could not get product image URL', [
                        'product_sku' => $productCode,
                        'exception' => $e->getMessage()
                    ]);
                }
            }
            
            // Provide a fallback image URL if none available
            if (!$imageUrl || !filter_var($imageUrl, FILTER_VALIDATE_URL)) {
                $imageUrl = 'https://via.placeholder.com/300x300.png?text=' . urlencode($productName);
            }

            // Build the basic required data
            $data = [
                'location_id' => (string) $locationId,
                'product_code' => (string) $productCode,
                'product_name' => (string) $productName,
                'source_url' => $productUrl,
                'image_url' => $imageUrl,
                'active' => ((int) $product->getStatus() === Status::STATUS_ENABLED)
            ];

            // Only add optional fields if they exist and are not empty
            if ($productCode) {
                $data['skus'] = $productCode;
            }

            $gtin = $this->resolveProductAttributeValue($product, ['gtin', 'ean', 'ean13', 'upc']);
            if ($gtin) {
                $data['gtins'] = $gtin;
            }

            $mpn = $this->resolveProductAttributeValue($product, ['mpn']);
            if ($mpn) {
                $data['mpns'] = $mpn;
            }

            $brand = $this->resolveProductAttributeValue($product, ['brand', 'manufacturer']);
            if ($brand) {
                $data['brand_name'] = $brand;
            }

            return $data;
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Failed to build product data', [
                'product_sku' => $product->getSku() ?? 'unknown',
                'exception' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * Try common Magento attribute codes until a non-empty value is found.
     */
    private function resolveProductAttributeValue(ProductInterface $product, array $attributeCodes): ?string
    {
        foreach ($attributeCodes as $attributeCode) {
            try {
                $value = $this->normalizeProductFieldValue($product->getData($attributeCode));
                if ($value) {
                    // manufacturer is often an option ID — prefer text label when available
                    if ($attributeCode === 'manufacturer' && is_numeric($value) && method_exists($product, 'getAttributeText')) {
                        $label = $product->getAttributeText('manufacturer');
                        if ($label) {
                            return is_array($label) ? implode(', ', $label) : (string) $label;
                        }
                    }
                    return $value;
                }
            } catch (\Exception $e) {
                // Attribute may not exist, try next
            }
        }

        return null;
    }

    private function normalizeProductFieldValue($value): ?string
    {
        if ($value === null) {
            return null;
        }

        if (is_array($value)) {
            $value = implode(',', array_filter(array_map('strval', $value), 'strlen'));
        }

        $value = trim((string) $value);

        return $value === '' ? null : $value;
    }

    private function sendInvitationRequest(array $data, int $storeId, bool $productInvite): bool
    {
        $result = $this->sendInvitationRequestWithDetails($data, $storeId, $productInvite);
        return $result['success'];
    }

    private function sendInvitationRequestWithDetails(array $data, int $storeId, bool $productInvite): array
    {
        $server = $this->getServerUrl($storeId);
        $apiToken = $this->getConfig(self::CONFIG_PATH_API_TOKEN, $storeId);

        if (!$apiToken) {
            $this->logger->error('Kiyoh API: Missing API token for invitation', [
                'store_id' => $storeId,
                'email' => $data['invite_email'] ?? 'unknown'
            ]);
            $this->reportInvite($storeId, false, null, 'missing api token');
            return ['success' => false, 'error_code' => 'MISSING_TOKEN', 'message' => 'Missing API token'];
        }

        $data['product_invite'] = $productInvite;

        $url = sprintf('%s/v1/invite/external', $server);
        $httpCode = null;

        $this->logger->info('Kiyoh API: Sending invitation request', [
            'url' => $url,
            'email' => $data['invite_email'],
            'product_invite' => $productInvite,
            'product_codes_count' => isset($data['product_code']) ? count($data['product_code']) : 0,
            'delay_days' => $data['delay'] ?? 'not_set',
            'language' => $data['language'] ?? 'not_set',
            'full_request_data' => $data
        ]);

        try {
            $ch = curl_init($url);
            $this->applyTlsVerification($ch);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_INVITATION);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'X-Publication-Api-Token: ' . $apiToken,
                'Content-Type: application/json'
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($response === false) {
                $this->logger->error('Kiyoh API: Invitation cURL failed', [
                    'email' => $data['invite_email'],
                    'curl_error' => $curlError,
                    'url' => $url
                ]);
                $this->reportInvite($storeId, false, $httpCode ?: null, $curlError !== '' ? $curlError : 'request failed');
                return ['success' => false, 'error_code' => 'CURL_ERROR', 'message' => $curlError];
            }

            $this->logger->info('Kiyoh API: Received invitation response', [
                'email' => $data['invite_email'],
                'http_code' => $httpCode,
                'response_body' => $response,
                'response_length' => strlen($response)
            ]);

            $responseData = json_decode($response, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->logger->error('Kiyoh API: Invalid JSON response for invitation', [
                    'email' => $data['invite_email'],
                    'response_body' => $response,
                    'json_error' => json_last_error_msg(),
                    'http_code' => $httpCode
                ]);
                $this->reportInvite($storeId, false, $httpCode ?: null, 'invalid response');
                return ['success' => false, 'error_code' => 'INVALID_JSON', 'message' => json_last_error_msg()];
            }

            if (isset($responseData['errorCode'])) {
                $errorCode = $responseData['errorCode'];
                $errorMessage = $responseData['message'] ?? $errorCode;
                
                $this->logger->error('Kiyoh API: Invitation API error', [
                    'email' => $data['invite_email'],
                    'error_response' => $responseData,
                    'request_data' => $data,
                    'http_code' => $httpCode
                ]);
                
                $this->reportInvite($storeId, false, $httpCode ?: null, (string) $errorCode);
                return [
                    'success' => false, 
                    'error_code' => $errorCode, 
                    'message' => $errorMessage,
                    'response_data' => $responseData
                ];
            }

            $this->logger->info('Kiyoh API: Invitation sent successfully', [
                'email' => $data['invite_email'],
                'response_data' => $responseData,
                'http_code' => $httpCode
            ]);
            
            $this->reportInvite($storeId, true, $httpCode ?: null, null);
            return [
                'success' => true, 
                'error_code' => null, 
                'message' => 'Invitation sent successfully',
                'response_data' => $responseData
            ];
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Invitation exception', [
                'email' => $data['invite_email'],
                'exception' => $e->getMessage(),
                'exception_trace' => $e->getTraceAsString(),
                'request_data' => $data
            ]);

            $this->reportInvite($storeId, false, $httpCode ?? null, $e->getMessage());
            return ['success' => false, 'error_code' => 'EXCEPTION', 'message' => $e->getMessage()];
        }
    }

    private function sendProductSyncRequest(array $productData, int $storeId): bool
    {
        $server = $this->getServerUrl($storeId);
        $apiToken = $this->getConfig(self::CONFIG_PATH_API_TOKEN, $storeId);

        if (!$apiToken) {
            $this->logger->error('Kiyoh API: Missing API token for product sync', [
                'product' => $productData['product_code'] ?? 'unknown'
            ]);
            $this->reportProductSync($storeId, false, null, 'missing api token', []);
            return false;
        }

        $url = sprintf('%s/v1/location/product/external', $server);
        $httpCode = null;
        $productCode = isset($productData['product_code']) ? [(string) $productData['product_code']] : [];

        try {
            $ch = curl_init($url);
            if ($ch === false) {
                throw new \RuntimeException('Failed to initialize cURL');
            }
            $this->applyTlsVerification($ch);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_INVITATION);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($productData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'X-Publication-Api-Token: ' . $apiToken,
                'Content-Type: application/json'
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($response === false) {
                $this->logger->error('Kiyoh API: Product sync cURL failed', [
                    'product' => $productData['product_code'] ?? 'unknown',
                    'curl_error' => $curlError,
                    'url' => $url
                ]);
                $this->reportProductSync($storeId, false, $httpCode ?: null, $curlError !== '' ? $curlError : 'request failed', []);
                return false;
            }

            $responseData = json_decode($response, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->logger->error('Kiyoh API: Invalid JSON response for product sync', [
                    'product' => $productData['product_code'] ?? 'unknown',
                    'http_code' => $httpCode,
                    'response' => substr($response, 0, 500),
                    'json_error' => json_last_error_msg()
                ]);
                $this->reportProductSync($storeId, false, $httpCode ?: null, 'invalid response', []);
                return false;
            }

            if (isset($responseData['errorCode'])) {
                $this->logger->error('Kiyoh API: Product sync error', [
                    'error' => $responseData,
                    'product' => $productData['product_code'] ?? 'unknown',
                    'http_code' => $httpCode
                ]);
                $this->reportProductSync($storeId, false, $httpCode ?: null, (string) $responseData['errorCode'], []);
                return false;
            }

            $this->logger->info('Kiyoh API: Product synced successfully', [
                'product' => $productData['product_code'] ?? 'unknown',
                'http_code' => $httpCode
            ]);
            $this->reportProductSync($storeId, true, $httpCode ?: null, null, $productCode);
            return true;
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Product sync exception', [
                'exception' => $e->getMessage(),
                'product' => $productData['product_code'] ?? 'unknown',
                'trace' => $e->getTraceAsString()
            ]);
            $this->reportProductSync($storeId, false, $httpCode ?? null, $e->getMessage(), []);
            return false;
        }
    }

    private function sendBulkProductSyncRequest(array $productsData, int $storeId): array
    {
        $server = $this->getServerUrl($storeId);
        $apiToken = $this->getConfig(self::CONFIG_PATH_API_TOKEN, $storeId);
        $locationId = $this->getConfig(self::CONFIG_PATH_LOCATION_ID, $storeId);

        $result = ['success' => 0, 'failed' => 0, 'errors' => []];

        if (!$apiToken) {
            $this->logger->error('Kiyoh API: Missing API token for bulk product sync');
            $result['failed'] = count($productsData);
            $result['errors'][] = 'Missing API token';
            $this->reportProductSync($storeId, false, null, 'missing api token', []);
            return $result;
        }

        if (empty($productsData)) {
            $this->logger->warning('Kiyoh API: Empty products data for bulk sync');
            return $result;
        }

        $requestData = [
            'location_id' => (string) $locationId,
            'products' => $productsData
        ];

        $url = sprintf('%s/v1/location/product/external/bulk', $server);
        $httpCode = null;
        $productCodes = [];
        foreach ($productsData as $productData) {
            if (isset($productData['product_code']) && is_string($productData['product_code'])) {
                $productCodes[] = $productData['product_code'];
            }
        }

        try {
            $ch = curl_init($url);
            if ($ch === false) {
                throw new \RuntimeException('Failed to initialize cURL');
            }
            $this->applyTlsVerification($ch);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_INVITATION * 5);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'X-Publication-Api-Token: ' . $apiToken,
                'Content-Type: application/json'
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($response === false) {
                $this->logger->error('Kiyoh API: Bulk product sync cURL failed', [
                    'curl_error' => $curlError,
                    'url' => $url,
                    'product_count' => count($productsData)
                ]);
                $result['failed'] = count($productsData);
                $result['errors'][] = 'cURL request failed: ' . $curlError;
                $this->reportProductSync($storeId, false, $httpCode ?: null, $curlError !== '' ? $curlError : 'request failed', []);
                return $result;
            }

            $responseData = json_decode($response, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->logger->error('Kiyoh API: Invalid JSON response for bulk sync', [
                    'http_code' => $httpCode,
                    'response' => substr($response, 0, 500),
                    'json_error' => json_last_error_msg(),
                    'product_count' => count($productsData)
                ]);
                $result['failed'] = count($productsData);
                $result['errors'][] = 'Invalid JSON response: ' . json_last_error_msg();
                $this->reportProductSync($storeId, false, $httpCode ?: null, 'invalid response', []);
                return $result;
            }

            if (isset($responseData['errorCode'])) {
                $this->logger->error('Kiyoh API: Bulk product sync error', [
                    'error' => $responseData,
                    'http_code' => $httpCode,
                    'product_count' => count($productsData)
                ]);
                $result['failed'] = count($productsData);
                $result['errors'][] = $responseData['errorCode'] . ': ' . ($responseData['message'] ?? 'Unknown error');
                $this->reportProductSync($storeId, false, $httpCode ?: null, (string) $responseData['errorCode'], []);
                return $result;
            }

            $result['success'] = count($productsData);
            $this->logger->info('Kiyoh API: Bulk products synced successfully', [
                'count' => count($productsData),
                'http_code' => $httpCode
            ]);
            $this->reportProductSync($storeId, true, $httpCode ?: null, null, $productCodes);
        } catch (\Exception $e) {
            $this->logger->error('Kiyoh API: Bulk product sync exception', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'product_count' => count($productsData)
            ]);
            $result['failed'] = count($productsData);
            $result['errors'][] = 'Exception: ' . $e->getMessage();
            $this->reportProductSync($storeId, false, $httpCode ?? null, $e->getMessage(), []);
        }

        return $result;
    }

    private function detectLanguageFromOrder(OrderInterface $order, int $storeId): string
    {
        $fallbackLanguage = $this->getConfig(self::CONFIG_PATH_FALLBACK_LANGUAGE, $storeId) ?: 'en';

        try {
            $currentLocale = $this->localeResolver->getLocale();
            if ($currentLocale) {
                return $this->mapMagentoLocaleToKiyohLanguage($currentLocale, $fallbackLanguage);
            }
        } catch (\Exception $e) {
            $this->logger->debug('Kiyoh API: Could not get current locale, falling back to store locale', ['exception' => $e->getMessage()]);
        }

        try {
            $storeLocale = $this->scopeConfig->getValue(
                'general/locale/code',
                ScopeInterface::SCOPE_STORE,
                $order->getStoreId()
            );

            if ($storeLocale) {
                return $this->mapMagentoLocaleToKiyohLanguage($storeLocale, $fallbackLanguage);
            }
        } catch (\Exception $e) {
            $this->logger->warning('Kiyoh API: Could not detect language from order', ['exception' => $e->getMessage()]);
        }

        return $fallbackLanguage;
    }

    private function mapMagentoLocaleToKiyohLanguage(string $magentoLocale, string $fallback = 'en'): string
    {
        $localeToKiyohMap = [
            'nl_NL' => 'nl',
            'fr_FR' => 'fr', 'fr_CA' => 'fr',
            'de_DE' => 'de', 'de_AT' => 'de', 'de_CH' => 'de',
            'en_US' => 'en', 'en_GB' => 'en', 'en_AU' => 'en', 'en_CA' => 'en', 'en_NZ' => 'en',
            'da_DK' => 'da',
            'hu_HU' => 'hu',
            'bg_BG' => 'bg',
            'ro_RO' => 'ro',
            'hr_HR' => 'hr',
            'ja_JP' => 'ja',
            'es_ES' => 'es', 'es_AR' => 'es', 'es_CL' => 'es', 'es_CO' => 'es', 'es_MX' => 'es', 'es_PE' => 'es', 'es_VE' => 'es',
            'it_IT' => 'it', 'it_CH' => 'it',
            'pt_PT' => 'pt',
            'tr_TR' => 'tr',
            'nb_NO' => 'no', 'nn_NO' => 'no',
            'sv_SE' => 'sv',
            'fi_FI' => 'fi',
            'pt_BR' => 'pt',
            'pl_PL' => 'pl',
            'sl_SI' => 'sl',
            'zh_Hans_CN' => 'zh', 'zh_Hant_HK' => 'zh', 'zh_Hant_TW' => 'zh',
            'ru_RU' => 'ru',
            'el_GR' => 'gr',
            'cs_CZ' => 'cs',
            'et_EE' => 'et',
            'lt_LT' => 'lt',
            'lv_LV' => 'lv',
            'sk_SK' => 'sk',
        ];

        if (isset($localeToKiyohMap[$magentoLocale])) {
            return $localeToKiyohMap[$magentoLocale];
        }

        $languageCode = substr($magentoLocale, 0, 2);
        $supportedKiyohLanguages = array_unique(array_values($localeToKiyohMap));
        
        if (in_array($languageCode, $supportedKiyohLanguages)) {
            return $languageCode;
        }

        $this->logger->debug('Kiyoh API: Unsupported language detected, using fallback', [
            'magento_locale' => $magentoLocale,
            'language_code' => $languageCode,
            'fallback' => $fallback
        ]);

        return $fallback;
    }

    /**
     * Certificate and hostname checks stay on for every outbound Kiyoh call.
     *
     * @param \CurlHandle|resource $ch
     */
    private function applyTlsVerification($ch): void
    {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    }

    private function getServerUrl(int $storeId): string
    {
        $server = $this->getConfig(self::CONFIG_PATH_SERVER, $storeId);
        $mapped = PublicationServerHost::baseUrlForConfigServer(is_string($server) ? $server : null);
        if ($mapped !== null) {
            return $mapped;
        }
        if ($server === null || (is_string($server) && trim($server) === '')) {
            return 'https://www.kiyoh.com';
        }
        $this->logger->warning('Kiyoh API: unknown server value in config, using kiyoh.com', [
            'server' => $server,
        ]);

        return 'https://www.kiyoh.com';
    }

    private function isEnabled(int $storeId): bool
    {
        return (bool) $this->getConfig(self::CONFIG_PATH_ENABLED, $storeId);
    }

    private function isInvitationsEnabled(int $storeId): bool
    {
        return (bool) $this->getConfig(self::CONFIG_PATH_INVITATIONS_ENABLED, $storeId);
    }

    private function getConfig(string $path, int $storeId)
    {
        $value = $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeId);
        
        // Decrypt API token if it's encrypted
        if ($path === self::CONFIG_PATH_API_TOKEN && $value) {
            $value = $this->encryptor->decrypt($value);
        }
        
        return $value;
    }

    public function validateLegacyCredentials(string $server, string $connector, string $companyId): array
    {
        $serverUrl = $this->mapLegacyServer($server);
        $url = sprintf(
            '%s/xml/recent_company_reviews.xml?connectorcode=%s&company_id=%s',
            $serverUrl,
            urlencode($connector),
            urlencode($companyId)
        );

        try {
            $ch = curl_init($url);
            $this->applyTlsVerification($ch);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_REVIEWS);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($response === false) {
                return ['success' => false, 'message' => 'Connection failed'];
            }

            if ($httpCode !== 200) {
                return ['success' => false, 'message' => 'Invalid HTTP response: ' . $httpCode];
            }

            libxml_use_internal_errors(true);
            $xml = simplexml_load_string($response);
            libxml_use_internal_errors(false);

            if ($xml === false) {
                return ['success' => false, 'message' => 'Invalid XML response'];
            }

            if (isset($xml->error)) {
                return ['success' => false, 'message' => (string) $xml->error];
            }

            if (!isset($xml->company)) {
                return ['success' => false, 'message' => 'Invalid credentials or company not found'];
            }

            return ['success' => true, 'message' => 'Credentials validated successfully'];
        } catch (\Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function validateNewApiCredentials(string $server, string $hash, string $locationId): array
    {
        $serverUrl = PublicationServerHost::baseUrlForConfigServer($server);
        if ($serverUrl === null) {
            return [
                'success' => false,
                'message' => 'Choose Server kiyoh.com or klantenvertellen.nl, save if needed, and try again.',
            ];
        }
        $url = sprintf(
            '%s/v1/publication/review/external/location/statistics?locationId=%s',
            $serverUrl,
            urlencode($locationId)
        );

        try {
            $ch = curl_init($url);
            $this->applyTlsVerification($ch);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_REVIEWS);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'X-Publication-Api-Token: ' . $hash
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($response === false) {
                return ['success' => false, 'message' => 'Connection failed'];
            }

            if ($httpCode === 401 || $httpCode === 403) {
                return ['success' => false, 'message' => 'Invalid API token'];
            }

            if ($httpCode !== 200) {
                return ['success' => false, 'message' => 'API request failed with HTTP ' . $httpCode];
            }

            $data = json_decode($response, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                return ['success' => false, 'message' => 'Invalid JSON response from API'];
            }

            if (isset($data['errorCode'])) {
                $errorMsg = $data['errorCode'];
                if (strpos($errorMsg, 'location') !== false || strpos($errorMsg, 'Location') !== false) {
                    return ['success' => false, 'message' => 'Invalid Location ID'];
                }
                return ['success' => false, 'message' => $errorMsg];
            }

            if (!isset($data['locationName'])) {
                return ['success' => false, 'message' => 'Location not found - check Location ID'];
            }

            $issuerCheck = $this->validateStatisticsResponseIssuer($server, $serverUrl, $hash, $locationId, $data);
            if ($issuerCheck !== null) {
                return ['success' => false, 'message' => $issuerCheck];
            }

            return ['success' => true, 'message' => 'Credentials validated successfully'];
        } catch (\Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * @param array<string, mixed> $data
     */
    private function validateStatisticsResponseIssuer(
        string $configServer,
        string $primaryBaseUrl,
        string $hash,
        string $locationId,
        array $data
    ): ?string {
        $tenantMsg = PublicationStatisticsValidator::tenantMismatchMessage($configServer, $data);
        if ($tenantMsg !== null) {
            return $tenantMsg;
        }
        $tenantRaw = $data['tenantId'] ?? null;
        if (is_numeric($tenantRaw)) {
            return null;
        }

        $otherBase = $primaryBaseUrl === 'https://www.klantenvertellen.nl'
            ? 'https://www.kiyoh.com'
            : 'https://www.klantenvertellen.nl';
        if ($this->statisticsSucceedsWithSameToken($otherBase, $hash, $locationId)) {
            return 'These credentials work on ' . ($otherBase === 'https://www.kiyoh.com' ? 'kiyoh.com' : 'klantenvertellen.nl')
                . ' but Server is set to ' . $configServer . '. Switch Server or use credentials for this platform.';
        }

        return null;
    }

    private function statisticsSucceedsWithSameToken(string $baseUrl, string $hash, string $locationId): bool
    {
        $url = sprintf(
            '%s/v1/publication/review/external/location/statistics?locationId=%s',
            $baseUrl,
            urlencode($locationId)
        );

        try {
            $ch = curl_init($url);
            $this->applyTlsVerification($ch);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, self::TIMEOUT_REVIEWS);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'X-Publication-Api-Token: ' . $hash,
            ]);
            $response = curl_exec($ch);
            $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
        } catch (\Exception $e) {
            return false;
        }

        if ($response === false || $httpCode !== 200) {
            return false;
        }
        $data = json_decode((string) $response, true);

        return is_array($data)
            && !isset($data['errorCode'])
            && isset($data['locationName']);
    }

    private function mapLegacyServer(string $server): string
    {
        $serverMap = [
            'kiyoh.nl' => 'https://www.kiyoh.nl',
            'kiyoh.com' => 'https://www.kiyoh.com'
        ];

        return $serverMap[$server] ?? 'https://www.kiyoh.nl';
    }

    /**
     * Health reporting must not change the invitation result or interrupt the caller.
     */
    private function reportInvite(int $storeId, bool $success, ?int $httpStatus, ?string $errorMessage): void
    {
        try {
            $this->healthReporter->noteInvite($storeId, $success, $httpStatus, $errorMessage);
        } catch (\Throwable $e) {
            $this->logger->error('Kiyoh health: invite report failed', [
                'store_id' => $storeId,
                'exception' => $e->getMessage(),
            ]);
        }
    }

    /**
     * @param list<string> $productCodes
     */
    private function reportProductSync(
        int $storeId,
        bool $success,
        ?int $httpStatus,
        ?string $errorMessage,
        array $productCodes
    ): void {
        try {
            $this->healthReporter->noteProductSync($storeId, $success, $httpStatus, $errorMessage, $productCodes);
        } catch (\Throwable $e) {
            $this->logger->error('Kiyoh health: product sync report failed', [
                'store_id' => $storeId,
                'exception' => $e->getMessage(),
            ]);
        }
    }
}
